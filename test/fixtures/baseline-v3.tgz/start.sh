#!/usr/bin/env bash
# Start the orchestrator in the background (nohup). Logs: ~/work/local-ai-dev/logs/orchestrator.log
set -euo pipefail
cd "$(dirname "$0")"
export PATH="$HOME/.nvm/versions/node/v22.16.0/bin:$HOME/.local/bin:/opt/homebrew/bin:$PATH"
LOG="$HOME/work/local-ai-dev/logs/orchestrator.log"; PIDFILE="$(pwd)/data/orchestrator.pid"
mkdir -p "$(dirname "$LOG")" data
if [ -f "$PIDFILE" ] && kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then echo "already running (pid $(cat "$PIDFILE"))"; exit 0; fi
nohup node --no-warnings server.js >> "$LOG" 2>&1 < /dev/null &
echo $! > "$PIDFILE"
sleep 1
if kill -0 "$(cat "$PIDFILE")" 2>/dev/null; then echo "started pid $(cat "$PIDFILE") -> http://127.0.0.1:4310  (log: $LOG)"; else echo "failed to start, see $LOG"; exit 1; fi
