'use strict';
const path = require('node:path');
const os = require('node:os');

const HOME = os.homedir();
const ROOT = __dirname;
const LOCAL = path.join(HOME, 'work', 'local-ai-dev');
const env = process.env;
const num = (v, d) => (Number.isFinite(Number(v)) && v !== undefined && v !== '' ? Number(v) : d);

module.exports = {
  HOST: '127.0.0.1', // hard-coded on purpose: never expose externally
  PORT: num(env.ORCH_PORT, 4310),
  HOME,
  // Legacy single-repo settings: now ONLY used once, to seed the first project when migrating a pre-projects DB
  // (or to seed a brand-new DB when ORCH_REPO is set explicitly).
  REPO: env.ORCH_REPO || '/path/to/repo',
  REPO_IS_EXPLICIT: !!env.ORCH_REPO,
  BASE_BRANCH: env.ORCH_BASE_BRANCH || 'main',
  PROJECTS_PARENT: env.ORCH_PROJECTS_PARENT || path.join(HOME, 'work'), // default parent dir for "create new project"
  WORKTREES: env.ORCH_WORKTREES || path.join(LOCAL, 'worktrees'),
  DB_PATH: env.ORCH_DB || path.join(ROOT, 'data', 'orchestrator.db'),
  LOG_DIR: env.ORCH_LOG_DIR || path.join(LOCAL, 'logs'),
  PUBLIC_DIR: path.join(ROOT, 'public'),
  OLLAMA_API_BASE: env.OLLAMA_API_BASE || 'http://127.0.0.1:11434',
  MODEL: env.ORCH_MODEL || 'ollama_chat/ornith:9b',
  AIDER_BIN: env.ORCH_AIDER_BIN || path.join(HOME, '.local', 'bin', 'aider'),
  // hard timeouts (ms) for every subprocess
  AIDER_TIMEOUT_MS: num(env.ORCH_AIDER_TIMEOUT_MS, 20 * 60 * 1000),
  INSTALL_TIMEOUT_MS: num(env.ORCH_INSTALL_TIMEOUT_MS, 10 * 60 * 1000),
  CHECK_TIMEOUT_MS: num(env.ORCH_CHECK_TIMEOUT_MS, 10 * 60 * 1000),
  GIT_TIMEOUT_MS: num(env.ORCH_GIT_TIMEOUT_MS, 60 * 1000),
  POLL_MS: num(env.ORCH_POLL_MS, 2000),
  DEFAULT_CHECK: 'npm run build',
  // ---- Cursor CLI engine (runs on Cursor's servers, uses the user's Cursor plan usage)
  CURSOR_BIN: env.ORCH_CURSOR_BIN || path.join(HOME, '.local', 'bin', 'agent'),
  CURSOR_MODEL: env.ORCH_CURSOR_MODEL || 'auto',                // default model for engine=cursor|auto
  CURSOR_REVIEW_MODEL: env.ORCH_CURSOR_REVIEW_MODEL || 'auto',  // default model for the advisory AI review
  CURSOR_TIMEOUT_MS: num(env.ORCH_CURSOR_TIMEOUT_MS, 15 * 60 * 1000),
  CURSOR_REVIEW_TIMEOUT_MS: num(env.ORCH_CURSOR_REVIEW_TIMEOUT_MS, 5 * 60 * 1000),
  CURSOR_DAILY_CAP: num(env.ORCH_CURSOR_DAILY_CAP, 10),         // max Cursor task invocations (tasks + plan runs) per local calendar day
  CURSOR_REVIEW_DAILY_CAP: num(env.ORCH_CURSOR_REVIEW_DAILY_CAP, 10), // separate cap for advisory reviews (they no longer eat the task cap)
  // engine=auto: escalating local -> cursor needs a dashboard click unless this is explicitly turned off
  ESCALATION_REQUIRE_APPROVAL: env.ORCH_ESCALATION_REQUIRE_APPROVAL !== '0',
  CURSOR_STATUS_TTL_MS: num(env.ORCH_CURSOR_STATUS_TTL_MS, 60 * 1000),
  CURSOR_MODELS_TTL_MS: num(env.ORCH_CURSOR_MODELS_TTL_MS, 10 * 60 * 1000),
  MAX_PARALLEL_CURSOR: Math.max(1, Math.floor(num(env.ORCH_MAX_PARALLEL_CURSOR, 2))), // concurrent Cursor tasks (different services); local tasks are always sequential
  CURSOR_IDE_BIN: env.ORCH_CURSOR_IDE_BIN || '',        // `cursor` CLI of the IDE (auto-detected when empty)
  OSASCRIPT_BIN: env.ORCH_OSASCRIPT_BIN || '/usr/bin/osascript',
  OPEN_DRY_RUN: env.ORCH_OPEN_DRY_RUN === '1',          // "Open in Cursor": report the command instead of launching (tests)
  // ---- Stage 4: shared context, routing, memory
  CONTEXT_DIR: env.ORCH_CONTEXT_DIR || path.join(path.dirname(env.ORCH_DB || path.join(ROOT, 'data', 'orchestrator.db')), 'context'),
  CONTEXT_MAX_CHARS: num(env.ORCH_CONTEXT_MAX_CHARS, 12000),    // cap of the whole context bundle (~3k tokens) so the 9B model keeps room
  CONTEXT_FILE_MAX_BYTES: 200 * 1024,
  LLM_MODEL: env.ORCH_ROUTER_MODEL || (env.ORCH_MODEL || 'ollama_chat/ornith:9b').replace(/^ollama(_chat)?\//, ''), // plain ollama model name
  ROUTER_API: env.ORCH_ROUTER_API === 'ollama' ? 'ollama' : 'openai', // openai = /v1/chat/completions (default), ollama = native /api/chat
  ROUTER_TIMEOUT_MS: num(env.ORCH_ROUTER_TIMEOUT_MS, 120000),
  ROUTER_MIN_CONFIDENCE: num(env.ORCH_ROUTE_MIN_CONFIDENCE, 0.55),
  ROUTER_SERVICES_MAX_CHARS: num(env.ORCH_ROUTER_SERVICES_MAX_CHARS, 6000), // Ollama's OpenAI endpoint loads the model with a 4096-token window: keep the prompt small
  ROUTE_COMPLEX_ENGINE: env.ORCH_ROUTE_COMPLEX_ENGINE || 'cursor',         // policy defaults (per-project settings override)
  ROUTE_SIMPLE_ENGINE: env.ORCH_ROUTE_SIMPLE_ENGINE || 'auto',             // auto = local first + escalation allowed
  ROUTE_PLAN_FIRST: env.ORCH_ROUTE_PLAN_FIRST !== '0',
  ROUTE_APPLY: env.ORCH_ROUTE_APPLY === 'auto' ? 'auto' : 'suggest',       // suggest = only a suggestion; you confirm at approve-start
  MEMORY_PROPOSALS: env.ORCH_MEMORY_PROPOSALS !== '0',
  MEMORY_TIMEOUT_MS: num(env.ORCH_MEMORY_TIMEOUT_MS, 180000),
  MEMORY_NUM_CTX: num(env.ORCH_MEMORY_NUM_CTX, 8192),
  EMPTY_CHECK: 'git diff --check',                                          // default check for empty-template projects
  MAX_REVIEW_DIFF_BYTES: 80 * 1024,
  MAX_LINE: 4000,
  MAX_DIFF_BYTES: 400 * 1024,
};
