'use strict';
// Stage 4 panels: services, shared context files, memory proposals, project settings. Loaded after app.js (shares its globals).
const svcCache = {};   // project id -> services[]
let memProps = [];     // memory proposals (all projects, newest first)

async function loadServices(pid) {
  try { svcCache[pid] = await api(`/projects/${pid}/services?archived=1`); } catch { svcCache[pid] = svcCache[pid] || []; }
  return svcCache[pid];
}
function fillServiceSelect() {
  const pid = Number($('#f-project').value); const sel = $('#f-service'); if (!sel) return;
  const prev = sel.value;
  const act = (svcCache[pid] || []).filter((s) => !s.archived);
  sel.replaceChildren(el('option', { value: '', textContent: 'none (whole repo)' }),
    ...(act.length ? [el('option', { value: 'auto', textContent: 'auto (local model picks from the service map)' })] : []),
    ...act.map((s) => el('option', { value: s.id, textContent: `${s.name} (${s.path})` })));
  sel.value = [...sel.options].some((o) => o.value === prev) ? prev : '';
}

async function loadMemProps() {
  try { memProps = await api('/memory-proposals'); } catch { return; }
  const pend = memProps.filter((m) => m.status === 'pending' && (!projFilter || String(m.project_id) === projFilter)).length;
  const b = $('#mem-badge');
  b.textContent = `memory: ${pend} pending`;
  b.className = 'badge pill ' + (pend ? 'cloud' : 'model');
}
$('#mem-badge').onclick = () => showProjectPanel('memory');

/** One memory proposal: editable text + Approve / Reject. Nothing reaches MEMORY.md until Approve. */
function proposalCard(m, after, inTask) {
  const c = el('div', { className: 'card membox' });
  c.append(el('div', {}, el('b', {}, `Memory proposal #${m.id} `), el('span', { className: 'badge ' + (m.status === 'pending' ? 's-pending' : m.status === 'approved' ? 's-done' : 's-rejected'), textContent: m.status }),
    el('span', { className: 'dim', textContent: ` ${projName(m.project_id)}${m.service_name ? ' / ' + m.service_name : ''}${!inTask && m.task_id ? ' | task #' + m.task_id + ' ' + (m.task_title || '') : ''}` })));
  if (m.status !== 'pending') { c.append(el('pre', { textContent: m.text })); return c; }
  const ta = el('textarea', { value: m.text, style: 'min-height:90px' });
  c.append(el('div', { className: 'dim', textContent: 'Drafted by the local model. Edit freely. It is appended to the project MEMORY.md only if you approve.' }), ta);
  const row = el('div', { className: 'row' });
  const go = (label, cls, path, body, confirmMsg) => {
    const b = el('button', { className: cls, textContent: label });
    b.onclick = async () => { if (confirmMsg && !confirm(confirmMsg)) return; b.disabled = true; try { await api(`/memory-proposals/${m.id}/${path}`, { body: body() }); } catch (e) { alert(e.message); } await after(); };
    row.append(b);
  };
  go('Approve & append to MEMORY', 'ok', 'approve', () => ({ text: ta.value }));
  go('Save edit', 'sec', 'update', () => ({ text: ta.value }));
  go('Reject', 'bad', 'reject', () => ({ reason: 'rejected in dashboard' }));
  c.append(row);
  return c;
}

// ---------------------------------------------------------------- project panel
let panelTab = 'services', panelCtx = null, panelFile = 'RULES.md';
const curProject = () => projects.find((p) => String(p.id) === projFilter);

async function showProjectPanel(tabName) {
  if (tabName) panelTab = tabName;
  const p = curProject();
  if (es) { es.close(); es = null; }
  panelOpen = true; selected = null;
  const d = $('#detail');
  if (!p) { d.replaceChildren(el('div', { className: 'dim', textContent: 'Select a project in the header first.' })); return; }
  const tabs = ['services', 'context', 'memory', 'sequences', 'settings'];
  const bar = el('div', { className: 'row tabs' }, el('b', {}, `Project ${p.name}  `),
    ...tabs.map((t) => el('button', { className: t === panelTab ? 'on' : '', textContent: t === 'memory' ? 'memory proposals' : t, onclick: () => showProjectPanel(t) })),
    el('button', { className: 'sec', textContent: 'close', onclick: () => { panelOpen = false; d.replaceChildren(el('div', { className: 'dim', textContent: 'Select a task.' })); } }));
  const body = el('div', { id: 'panel-body' });
  d.replaceChildren(bar, body);
  await loadServices(p.id);
  if (panelTab === 'services') renderServices(p, body);
  else if (panelTab === 'context') await renderContext(p, body);
  else if (panelTab === 'memory') await renderMemory(p, body);
  else if (panelTab === 'sequences') await renderSequences(p, body);
  else renderSettings(p, body);
  loadList();
}
$('#btn-panel').onclick = () => showProjectPanel();

// ---- services
function serviceForm(p, s, body, done) {
  const f = el('div', { className: 'card tight' });
  const inp = (label, key, ph) => { const i = el('input', { value: (s && s[key]) || (body && body[key]) || '', placeholder: ph || '' }); f[key] = i; return el('div', {}, el('label', { textContent: label }), i); };
  f.append(el('div', { className: 'grid3' }, inp('Name (slug)', 'name', 'billing'), inp('Path in repo (relative)', 'path', 'services/billing'), inp('Check command (override; blank = project)', 'check_cmd', 'npm test')));
  f.append(inp('Description / responsibility (the router reads this)', 'description', 'what this service owns'), inp('Owner notes', 'notes', ''));
  const msg = el('span', { className: 'msg' });
  const save = el('button', { textContent: s ? 'Save' : 'Add service' });
  save.onclick = async () => {
    msg.textContent = '';
    const b = { name: f.name.value, path: f.path.value, check_cmd: f.check_cmd.value, description: f.description.value, notes: f.notes.value };
    try { await api(s ? `/services/${s.id}/update` : `/projects/${p.id}/services`, { body: b }); await done(); } catch (e) { msg.textContent = e.message; }
  };
  const row = el('div', { className: 'row' }, save, msg);
  if (s) {
    const ar = el('button', { className: s.archived ? 'ok' : 'bad', textContent: s.archived ? 'Unarchive' : 'Archive' });
    ar.onclick = async () => { try { await api(`/services/${s.id}/${s.archived ? 'unarchive' : 'archive'}`, { body: {} }); await done(); } catch (e) { msg.textContent = e.message; } };
    row.append(ar);
  }
  f.append(row);
  return f;
}
async function renderServices(p, body) {
  const redo = () => showProjectPanel('services');
  body.append(el('div', { className: 'dim', textContent: `Services are subfolders of this project's repo (${p.path}). v1: a service must live inside the project repo; another repo = another project. Tasks run with the service folder as working root.` }));
  for (const s of svcCache[p.id] || []) {
    body.append(el('details', { className: 'card', open: !s.archived && (svcCache[p.id].length <= 4) },
      el('summary', {}, `${s.name}  `, el('span', { className: 'dim', textContent: `${s.path}${s.exists ? '' : '  (missing in checkout)'}${s.archived ? '  [archived]' : ''}` })),
      serviceForm(p, s, null, redo)));
  }
  body.append(el('b', {}, 'Add service'), serviceForm(p, null, null, redo));
  const det = el('div', { className: 'card' }, el('b', {}, 'Auto-detect '), el('span', { className: 'dim', textContent: 'top-level folders (and services/, packages/, apps/ children) with package.json, pyproject.toml, go.mod, ... on the default branch' }));
  const btn = el('button', { className: 'sec', textContent: 'Detect services' }); const out = el('div', {});
  btn.onclick = async () => {
    out.replaceChildren('detecting...');
    try {
      const r = await api(`/projects/${p.id}/services/detect`);
      out.replaceChildren(...(r.suggestions.length ? r.suggestions.map((x) => {
        const b = el('button', { className: 'sec', textContent: x.registered ? 'registered' : 'Add', disabled: x.registered });
        b.onclick = async () => { try { await api(`/projects/${p.id}/services`, { body: { name: x.name, path: x.path, description: x.description, check_cmd: x.suggested_check_cmd || '' } }); await redo(); } catch (e) { alert(e.message); } };
        return el('div', { className: 'row' }, b, el('span', { textContent: `${x.name}  ${x.path}  [${x.kind}]  ${x.suggested_check_cmd ? 'check: ' + x.suggested_check_cmd : ''}  ${x.description}` }));
      }) : ['nothing detected']));
    } catch (e) { out.textContent = e.message; }
  };
  det.append(el('div', { className: 'row' }, btn), out);
  body.append(det);
}

// ---- context files
async function renderContext(p, body) {
  let c;
  try { c = await api(`/projects/${p.id}/context`); } catch (e) { body.append(el('div', { className: 'msg', textContent: e.message })); return; }
  panelCtx = c;
  if (!c.files.find((f) => f.name === panelFile)) panelFile = 'RULES.md';
  body.append(el('div', { className: 'dim', textContent: `Shared context for ALL engines (local + Cursor). Managed copy: ${c.dir}. Saving only updates the managed copy (used by the next task). "Export to repo" commits .ai/ onto a new branch and registers a review task - it reaches ${c.default_branch} only through your approve-merge. Bundle cap: ${c.max_chars} chars.` }));
  const sel = el('select', { onchange: () => { panelFile = sel.value; showProjectPanel('context'); } },
    ...c.files.map((f) => el('option', { value: f.name, textContent: `${f.name}${f.exists ? '' : ' (not created)'}  [repo: ${f.repo_state}]` })));
  sel.value = panelFile;
  const f = c.files.find((x) => x.name === panelFile);
  const ta = el('textarea', { className: 'big', value: f.content });
  const msg = el('span', { className: 'msg' });
  const mk = (label, cls, fn) => el('button', { className: cls, textContent: label, onclick: async () => { msg.textContent = ''; try { await fn(); } catch (e) { msg.textContent = e.message; } } });
  const row = el('div', { className: 'row' },
    mk('Save (managed copy)', 'ok', async () => { await api(`/projects/${p.id}/context/save`, { body: { file: f.name, content: ta.value } }); msg.className = 'good'; msg.textContent = 'saved'; setTimeout(() => showProjectPanel('context'), 400); }));
  if (f.name === 'SERVICES.md') row.append(mk('Load generated draft from services table', 'sec', async () => { if (!ta.value.trim() || confirm('Replace the editor text with a generated draft? (nothing is saved until you click Save)')) ta.value = c.services_draft; }));
  row.append(mk('Export all to repo (new branch + review task)', 'sec', async () => {
    if (!confirm(`Commit the managed context files to .ai/ on a NEW branch from ${c.default_branch} and create a review task? Nothing is merged.`)) return;
    const r = await api(`/projects/${p.id}/context/export`, { body: {} });
    alert(r.changed ? `Created branch ${r.branch} and review task #${r.task.id}. Review/merge it from the task list.` : r.message); await loadList(); }));
  row.append(mk('Import from repo (.ai/ on default branch)', 'sec', async () => {
    if (!confirm('Overwrite the managed copy with the .ai/ files from the default branch?')) return;
    const r = await api(`/projects/${p.id}/context/import`, { body: {} }); alert(r.note); showProjectPanel('context'); }));
  row.append(msg);
  body.append(el('div', { className: 'row' }, sel), ta, row);
  // bundle preview
  const pv = el('details', { className: 'card' }, el('summary', {}, 'Preview the context bundle an engine would receive'));
  const ps = el('select', {}, el('option', { value: '', textContent: 'no service' }), ...(svcCache[p.id] || []).filter((s) => !s.archived).map((s) => el('option', { value: s.id, textContent: s.name })));
  const pp = el('input', { placeholder: 'task prompt (used to pick relevant MEMORY entries)' }); const po = el('pre', {});
  pv.append(el('div', { className: 'row' }, ps, pp, el('button', { className: 'sec', textContent: 'Preview', onclick: async () => {
    const r = await api(`/projects/${p.id}/context/preview`, { body: { service_id: ps.value || null, prompt: pp.value } });
    po.textContent = `${r.manifest.total_chars}/${r.manifest.max_chars} chars; parts: ${r.manifest.parts.map((x) => `${x.name} ${x.chars}${x.truncated ? ' (truncated)' : ''}`).join(', ')}\n\n${r.text}`; } })), po);
  body.append(pv);
}

// ---- memory
async function renderMemory(p, body) {
  await loadMemProps();
  const mine = memProps.filter((m) => m.project_id === p.id);
  const redo = () => showProjectPanel('memory');
  body.append(el('div', { className: 'dim', textContent: 'After a task reaches review the local model drafts 1-5 notes. They are appended to MEMORY.md only when you approve. Approved entries are used as context by later tasks.' }));
  if (!mine.length) body.append(el('div', { className: 'dim', textContent: 'No proposals yet for this project.' }));
  for (const m of mine) body.append(proposalCard(m, redo, false));
}

// ---- settings
function renderSettings(p, body) {
  const e = p.settings_effective || {}; const ov = p.settings || {};
  const f = el('div', { className: 'card tight' });
  const inp = (label, val, ph) => { const i = el('input', { value: val ?? '', placeholder: ph || '' }); return [i, el('div', {}, el('label', { textContent: label }), i)]; };
  const sel = (label, opts, val) => { const s = el('select', {}, ...opts.map((o) => el('option', { value: o, textContent: o }))); s.value = val; return [s, el('div', {}, el('label', { textContent: label }), s)]; };
  const [check, checkD] = inp('Check command (project default)', p.check_cmd);
  const [install, installD] = inp('Install command (optional)', p.install_cmd);
  const [eng, engD] = sel('Default engine for new tasks', ['local', 'cursor', 'auto'], p.engine);
  const [apply, applyD] = sel('Routing: apply suggestion automatically? (suggest = you confirm at approve-start)', ['suggest', 'auto'], e.route_apply);
  const [cx, cxD] = sel('Routing: engine for complex / needs-thinking tasks', ['cursor', 'auto', 'local'], e.complex_engine);
  const [sx, sxD] = sel('Routing: engine for simple tasks (auto = local first, escalation allowed)', ['auto', 'local', 'cursor'], e.simple_engine);
  const [pf, pfD] = sel('Routing: plan first for complex tasks routed to cursor', ['true', 'false'], String(!!e.plan_first_complex));
  const [mp, mpD] = sel('Generate memory proposals after tasks', ['true', 'false'], String(!!e.memory_proposals));
  const [cap, capD] = inp('Context bundle cap (chars, 2000..60000)', e.context_max_chars);
  f.append(el('div', { className: 'grid2' }, checkD, installD, engD, capD, applyD, mpD, cxD, sxD, pfD));
  if (p.check_warning) f.append(el('div', { className: 'msg', textContent: p.check_warning }));
  const msg = el('span', { className: 'msg' });
  f.append(el('div', { className: 'row' }, el('button', { textContent: 'Save settings', onclick: async () => {
    msg.textContent = '';
    try {
      await api(`/projects/${p.id}/update`, { body: { check_cmd: check.value, install_cmd: install.value, engine: eng.value,
        settings: { route_apply: apply.value, complex_engine: cx.value, simple_engine: sx.value, plan_first_complex: pf.value, memory_proposals: mp.value, context_max_chars: cap.value } } });
      await loadProjects(); showProjectPanel('settings');
    } catch (er) { msg.textContent = er.message; }
  } }), msg));
  body.append(f, el('div', { className: 'dim', textContent: `Env defaults: ${JSON.stringify(cfg && cfg.routing_defaults)}; explicitly overridden for this project: ${JSON.stringify(ov)}` }));
}

// ---- multi-service sequences
async function renderSequences(p, body) {
  const redo = () => showProjectPanel('sequences');
  body.append(el('div', { className: 'dim', textContent: 'A sequence = ordered steps (usually one per service), each its own task/branch/check/review. One start approval for the whole sequence; steps run in order. "stack": a step is cut from the previous step\'s branch once that step passed its checks (merge them in order; merging a later step also brings the earlier ones). "merged": a step waits until the previous step is merged. A failed/rejected step blocks the rest.' }));
  let groups = [];
  try { groups = await api(`/groups?project_id=${p.id}`); } catch (e) { body.append(el('div', { className: 'msg', textContent: e.message })); }
  for (const g of groups) {
    const c = el('div', { className: 'card' }, el('b', {}, `#${g.id} ${g.title} `), el('span', { className: 'badge model', textContent: g.dependency }));
    for (const s of g.steps) c.append(el('div', { className: 'row' }, el('span', { className: 'badge s-' + s.status, textContent: s.status }),
      el('a', { href: '#', textContent: `step ${s.step_no}: #${s.id} ${s.title} [${s.service_name || 'no service'}, ${s.engine}]${s.supervised ? ' SUPERVISED' : ''}`, onclick: (ev) => { ev.preventDefault(); panelOpen = false; select(s.id); } })));
    if (g.steps.some((s) => s.status === 'pending')) {
      const row = el('div', { className: 'row' });
      row.append(el('button', { className: 'ok', textContent: 'Approve start of all pending steps', onclick: async () => { if (!confirm('Approve the whole sequence? Cursor steps use your Pro usage.')) return; try { await api(`/groups/${g.id}/approve-start`, { body: {} }); } catch (e) { alert(e.message); } await redo(); } }),
        el('button', { className: 'bad', textContent: 'Reject', onclick: async () => { const r = prompt('Reason (required):'); if (!r) return; try { await api(`/groups/${g.id}/reject`, { body: { reason: r } }); } catch (e) { alert(e.message); } await redo(); } }));
      c.append(row);
    }
    body.append(c);
  }
  // create form
  const f = el('div', { className: 'card tight' }, el('b', {}, 'New sequence'));
  const title = el('input', { placeholder: 'sequence title' });
  const dep = el('select', {}, el('option', { value: 'stack', textContent: 'stack (next step on top of previous branch once it passed checks)' }), el('option', { value: 'merged', textContent: 'merged (wait until previous step is merged)' }));
  f.append(el('label', { textContent: 'Title' }), title, el('label', { textContent: 'Dependency' }), dep);
  const stepsBox = el('div', {}); const rows = [];
  const addStep = () => {
    const sv = el('select', {}, el('option', { value: 'none', textContent: 'no service' }), ...(svcCache[p.id] || []).filter((s) => !s.archived).map((s) => el('option', { value: s.id, textContent: s.name })));
    const en = el('select', {}, el('option', { value: 'local', textContent: 'local' }), el('option', { value: 'auto', textContent: 'auto' }), el('option', { value: 'cursor', textContent: 'cursor' }));
    const st = el('input', { placeholder: 'step title (optional)' }); const pr = el('textarea', { placeholder: 'step prompt', style: 'min-height:60px' }); const fl = el('input', { placeholder: 'files (comma separated, relative to the service folder)' });
    rows.push({ sv, en, st, pr, fl });
    stepsBox.append(el('div', { className: 'card' }, el('b', {}, `Step ${rows.length}`), el('div', { className: 'grid2' }, el('div', {}, el('label', { textContent: 'Service' }), sv), el('div', {}, el('label', { textContent: 'Engine' }), en)), st, pr, fl));
  };
  addStep(); addStep();
  const msg = el('span', { className: 'msg' });
  f.append(stepsBox, el('div', { className: 'row' }, el('button', { className: 'sec', textContent: '+ step', onclick: () => { if (rows.length < 8) addStep(); } }),
    el('button', { textContent: 'Create sequence (pending; nothing starts yet)', onclick: async () => {
      msg.textContent = '';
      try {
        await api(`/projects/${p.id}/groups`, { body: { title: title.value, dependency: dep.value, steps: rows.filter((r) => r.pr.value.trim()).map((r) => ({ service_id: r.sv.value, engine: r.en.value, title: r.st.value, prompt: r.pr.value, files: r.fl.value })) } });
        await redo(); loadList();
      } catch (e) { msg.textContent = e.message; }
    } }), msg));
  body.append(f);
}
