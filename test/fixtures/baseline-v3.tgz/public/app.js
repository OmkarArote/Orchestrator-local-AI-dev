'use strict';
const $ = (s) => document.querySelector(s);
let panelOpen = false, lastSig = '', selected = null, es = null, tab = 'log', tasks = [], projects = [], cfg = null, projFilter = localStorage.getItem('projFilter') || '';

const api = async (p, opt) => {
  const r = await fetch('/api' + p, opt && opt.body
    ? { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(opt.body) } : undefined);
  const j = await r.json().catch(() => ({}));
  if (!r.ok) { const e = new Error(j.error || r.statusText); e.data = j; e.status = r.status; throw e; }
  return j;
};
const el = (tag, props = {}, ...kids) => { const e = Object.assign(document.createElement(tag), props); kids.forEach((k) => e.append(k)); return e; };
const hhmmss = (iso) => new Date(iso).toLocaleTimeString();
const projName = (id) => (projects.find((p) => p.id === id) || {}).name || `#${id}`;
const isCloud = (t) => t.engine !== 'local';

// ---------------------------------------------------------------- projects
async function loadProjects() {
  try { projects = await api('/projects'); } catch { return; }
  const sel = $('#proj-sel'); const cur = projFilter;
  sel.replaceChildren(el('option', { value: '', textContent: 'All projects' }), ...projects.map((p) => el('option', { value: p.id, textContent: p.name })));
  if (cur && !projects.find((p) => String(p.id) === cur)) projFilter = '';
  sel.value = projFilter;
  const fp = $('#f-project'); const prev = fp.value;
  fp.replaceChildren(...projects.map((p) => el('option', { value: p.id, textContent: p.name })));
  fp.value = prev && projects.find((p) => String(p.id) === prev) ? prev : (projFilter || (projects[0] ? String(projects[0].id) : ''));
  onProjectChosen();
  $('#btn-archive').disabled = !projFilter;
  const noActive = !projects.some((p) => !p.archived);
  $('#empty-proj').style.display = noActive ? '' : 'none';
  if (noActive) $('#add-proj').open = true;
  $('#create').disabled = noActive;
  if (noActive) $('#msg').textContent = 'Add a project first.'; else if ($('#msg').textContent === 'Add a project first.') $('#msg').textContent = '';
}
$('#proj-sel').onchange = (e) => { projFilter = e.target.value; localStorage.setItem('projFilter', projFilter); if (projFilter) $('#f-project').value = projFilter; $('#btn-archive').disabled = !projFilter; onProjectChosen(); loadList(); };
function onProjectChosen() {
  const p = projects.find((x) => String(x.id) === $('#f-project').value);
  if (p) loadServices(p.id).then(fillServiceSelect);
  $('#f-check-default').textContent = p ? p.check_cmd : '-';
  if (p && !$('#f-engine').dataset.touched) { $('#f-engine').value = p.engine; syncEngine(); }
}
$('#f-project').onchange = () => { $('#f-engine').dataset.touched = ''; onProjectChosen(); };
$('#btn-archive').onclick = async () => {
  const p = projects.find((x) => String(x.id) === projFilter); if (!p) return;
  if (!confirm(`Archive project '${p.name}'? Its tasks/history are kept; no new tasks can be created. The repo on disk is untouched.`)) return;
  try { await api(`/projects/${p.id}/archive`, { body: {} }); projFilter = ''; localStorage.setItem('projFilter', ''); await loadProjects(); await loadList(); } catch (e) { alert(e.message); }
};

$('#ap-inspect').onclick = async () => {
  $('#ap-msg').textContent = '';
  try {
    const i = await api('/projects/inspect', { body: { path: $('#ap-path').value } });
    const pre = $('#ap-info'); pre.style.display = '';
    pre.textContent = [`path: ${i.path}`, `git repo: ${i.is_git_repo} (commits: ${i.has_commits})`, `default branch: ${i.default_branch || '-'}`,
      `stack: ${i.stack ? i.stack.kind : '-'} scripts: ${i.stack ? Object.keys(i.stack.scripts).join(', ') || '-' : '-'}`,
      `suggested check: ${(i.stack && i.stack.suggested_check_cmd) || '-'}`, ...i.warnings.map((w) => 'WARNING: ' + w)].join('\n');
    if (!$('#ap-name').value) $('#ap-name').value = i.suggested_name;
    if (i.stack && i.stack.suggested_check_cmd) $('#ap-check').value = i.stack.suggested_check_cmd;
  } catch (e) { $('#ap-msg').textContent = e.message; }
};
$('#ap-add').onclick = async () => {
  $('#ap-msg').textContent = '';
  const body = { path: $('#ap-path').value, name: $('#ap-name').value, check_cmd: $('#ap-check').value, install_cmd: $('#ap-install').value, engine: $('#ap-engine').value };
  const send = () => api('/projects/add', { body });
  try {
    let r;
    try { r = await send(); }
    catch (e) {
      if (e.data && e.data.needs_git_init) {
        if (!confirm('This directory is not a git repo with commits.\n\nRun `git init -b main` and make a baseline commit of everything in it (a .gitignore is added if missing)?')) throw new Error('cancelled: not a git repo');
        body.confirm_git_init = true; r = await send();
      } else throw e;
    }
    ['#ap-path', '#ap-name', '#ap-check', '#ap-install'].forEach((s) => ($(s).value = '')); $('#ap-info').style.display = 'none';
    projFilter = String(r.project.id); localStorage.setItem('projFilter', projFilter);
    await loadProjects(); await loadList();
  } catch (e) { $('#ap-msg').textContent = e.message; }
};
$('#np-create').onclick = async () => {
  $('#np-msg').textContent = '';
  try {
    const r = await api('/projects/create', { body: { name: $('#np-name').value, parent_dir: $('#np-parent').value, template: $('#np-tpl').value, check_cmd: $('#np-check').value } });
    ['#np-name', '#np-check'].forEach((s) => ($(s).value = ''));
    projFilter = String(r.project.id); localStorage.setItem('projFilter', projFilter);
    await loadProjects(); await loadList();
    if (r.note) alert(r.note);
  } catch (e) { $('#np-msg').textContent = e.message; }
};

// ---------------------------------------------------------------- cursor status / models
async function loadCursor() {
  const b = $('#cursor-badge');
  try {
    const s = await api('/cursor/status');
    const u = s.usage;
    b.textContent = `Cursor ${s.logged_in ? 'logged in' + (s.email ? ' as ' + s.email : '') : 'NOT logged in'} | today: tasks+plans ${u.used}/${u.cap} (${u.tasks} tasks, ${u.plans || 0} plans) | reviews ${u.reviews}/${u.review_cap}`;
    b.className = 'badge ' + (s.logged_in ? (u.remaining > 0 ? 'cloud' : 's-failed') : 's-failed');
    b.title = 'Cursor tasks run on Cursor servers and use your Pro usage. Daily cap resets at local midnight.';
  } catch (e) { b.textContent = 'cursor: unavailable (' + e.message + ')'; b.className = 'badge s-failed'; }
}
async function loadModels() {
  try {
    const m = await api('/cursor/models');
    $('#models').replaceChildren(...m.models.map((x) => el('option', { value: x.id, textContent: x.name })));
  } catch { /* datalist stays empty; free text still works */ }
}
function syncEngine() {
  const e = $('#f-engine').value;
  $('#f-cursor-opts').style.display = e === 'local' ? 'none' : '';
  $('#f-esc-wrap').style.display = e === 'auto' || e === 'auto-route' ? '' : 'none';
  $('#f-plan-wrap').style.display = e === 'cursor' || e === 'auto-route' ? '' : 'none';
  if (e !== 'auto' && e !== 'auto-route') $('#f-esc').checked = false;
  if (e !== 'cursor' && e !== 'auto-route') $('#f-plan').checked = false;
  if (e !== 'local' && !$('#f-model').value) $('#f-model').placeholder = (cfg && cfg.cursor_default_model) || 'auto';
}
$('#f-engine').onchange = () => { $('#f-engine').dataset.touched = '1'; syncEngine(); };

// ---------------------------------------------------------------- task list
function badges(t) {
  const out = [el('span', { className: 'badge e-' + t.engine, textContent: t.engine === 'local' ? 'LOCAL' : t.engine === 'cursor' ? '\u2601 CURSOR' : 'AUTO' })];
  if (isCloud(t)) out.push(el('span', { className: 'badge model', textContent: t.model_used ? `${t.model || 'auto'} \u2192 ${t.model_used}` : t.model || 'auto' }));
  if (t.service_name) out.push(el('span', { className: 'badge model', textContent: 'svc: ' + t.service_name }));
  if (t.routing_state === 'routing') out.push(el('span', { className: 'badge s-pending', textContent: 'routing\u2026' }));
  else if (t.routing_source) out.push(el('span', { className: 'badge model', textContent: 'routed: ' + t.routing_source }));
  if (t.supervised) out.push(el('span', { className: 'badge s-awaiting_escalation', textContent: 'SUPERVISED' }));
  if (t.group_id) out.push(el('span', { className: 'badge model', textContent: `seq #${t.group_id} step ${t.step_no}` }));
  if (t.plan_first) out.push(el('span', { className: 'badge model', textContent: 'plan first' + (t.plan_state ? ': ' + t.plan_state : '') }));
  return out;
}
async function loadList() {
  try { tasks = await api('/tasks' + (projFilter ? `?project_id=${projFilter}` : '')); } catch { return; }
  await loadMemProps();
  const list = $('#list'); list.replaceChildren();
  for (const t of tasks) {
    const c = el('div', { className: 'card task' + (t.id === selected ? ' sel' : '') },
      el('div', { style: 'min-width:0' }, el('div', { className: 't', title: t.title, textContent: `#${t.id} ${t.title}` }),
        el('div', { className: 'sub' }, `${t.project_name || projName(t.project_id)} `, ...badges(t))),
      el('span', { className: 'badge s-' + t.status }, t.status));
    c.onclick = () => select(t.id);
    list.append(c);
  }
  if (selected) renderHeader();
  loadCursor();
}
function select(id) { selected = id; panelOpen = false; lastSig = ''; buildDetail(); loadList(); }

function buildDetail() {
  if (es) { es.close(); es = null; }
  panelOpen = false;
  const t0 = tasks.find((x) => x.id === selected);
  if (!t0) return;
  $('#detail').replaceChildren(
    el('div', { id: 'hdr' }),
    el('div', { className: 'row tabs' },
      el('button', { id: 'tab-log', textContent: 'Live log', onclick: () => setTab('log') }),
      el('button', { id: 'tab-diff', textContent: `Diff vs base`, onclick: () => setTab('diff') })),
    el('pre', { id: 'log' }), el('pre', { id: 'diff', style: 'display:none;max-height:70vh' }));
  renderHeader(); setTab('log'); startStream();
}

const ovr = {};  // per-task override form state; survives the periodic re-render
const planEdit = {};
function initOverrides(t) {
  const r = t.routing, sug = r && r.suggestion, req = (r && r.request) || { service: true, engine: true };
  const o = { service_id: t.service_id || '', engine: t.engine, model: t.model || '', plan_first: !!t.plan_first, allow_escalation: !!t.allow_escalation };
  if (sug) {
    if (req.service) o.service_id = sug.service_id || '';
    if (req.engine) { o.engine = sug.policy.engine; o.plan_first = !!sug.policy.plan_first; o.allow_escalation = !!sug.policy.allow_escalation; }
  }
  return o;
}
const rerender = () => { lastSig = ''; renderHeader(); };

function routingCard(t) {
  const r = t.routing;
  if (t.routing_state === 'routing') return el('div', { className: 'card routebox', textContent: `Routing in progress: the local model (${cfg ? cfg.router.model : 'ornith:9b'}) is reading the service map\u2026` });
  if (!r || !r.suggestion) return t.route_requested ? el('div', { className: 'card routebox', textContent: 'Routing was requested but produced no suggestion (' + (t.routing_state || '?') + '). You can still choose manually below.' }) : null;
  const s = r.suggestion;
  const c = el('div', { className: 'card routebox' },
    el('b', {}, `Routing suggestion (${s.source}) `), el('span', { className: 'dim', textContent: '- a suggestion only; you confirm or override it when approving' }),
    el('div', { textContent: `service: ${s.service || '(none / cross-service)'}  |  confidence: ${s.confidence}  |  difficulty: ${s.difficulty}  |  needs thinking: ${s.needs_thinking}` }),
    el('div', { className: 'dim', textContent: `policy: ${s.policy.rule}` }),
    el('div', { className: 'dim', textContent: `reason: ${s.reason}` }));
  if (r.fallback_reason) c.append(el('div', { className: 'msg', textContent: `fallback to keyword matching: ${r.fallback_reason}` }));
  if (r.llm) c.append(el('div', { className: 'dim', textContent: `local model ${r.llm.model} via ${r.llm.api}: ${r.llm.ms} ms, ${r.llm.prompt_tokens ?? '?'} prompt tokens${r.llm.error ? ' | problem: ' + r.llm.error : ''}` }));
  return c;
}

function overrideForm(t, o) {
  const svcs = (svcCache[t.project_id] || []).filter((x) => !x.archived);
  const sel = (opts, val, on) => { const e = el('select', {}); for (const [v, l] of opts) e.append(el('option', { value: v, textContent: l })); e.value = val; e.onchange = () => on(e.value); return e; };
  const box = el('div', { className: 'card' }, el('b', {}, 'Start settings (override before approving)'));
  const g = el('div', { className: 'grid2 tight' });
  g.append(el('div', {}, el('label', { textContent: 'Service' }), sel([['', 'none (whole repo)'], ...svcs.map((x) => [String(x.id), `${x.name} (${x.path})`])], String(o.service_id || ''), (v) => { o.service_id = v; })));
  g.append(el('div', {}, el('label', { textContent: 'Engine' }), sel([['local', 'local (aider + ollama)'], ['auto', 'auto (local, then escalate)'], ['cursor', '\u2601 cursor (Pro usage)']], o.engine, (v) => { o.engine = v; if (v !== 'cursor') o.plan_first = false; if (v !== 'auto') o.allow_escalation = false; if (v === 'auto' && t.routing) o.allow_escalation = true; rerender(); })));
  box.append(g);
  if (o.engine !== 'local') {
    const m = el('input', { value: o.model, placeholder: (cfg && cfg.cursor_default_model) || 'auto', oninput: () => { o.model = m.value; } });
    box.append(el('label', { textContent: 'Cursor model' }), m);
  }
  const chk = (label, key) => { const c = el('input', { type: 'checkbox', checked: !!o[key], onchange: () => { o[key] = c.checked; } }); return el('label', { className: 'chk' }, c, label); };
  if (o.engine === 'cursor') box.append(chk('plan first: Cursor writes a plan (--mode plan) and waits for your approval before coding', 'plan_first'));
  if (o.engine === 'auto') box.append(chk('allow escalation to Cursor if local fails (still needs your click)', 'allow_escalation'));
  if (o.engine !== 'local') box.append(el('div', { className: 'dim', textContent: '\u2601 runs on Cursor servers and uses your Pro usage (daily cap applies).' }));
  return box;
}

function renderHeader() {
  const t = tasks.find((x) => x.id === selected); const h = $('#hdr'); if (!t || !h) return;
  const mp = memProps.filter((m) => m.task_id === t.id);
  const sig = JSON.stringify([t, mp, (svcCache[t.project_id] || []).length, cfg && cfg.router]);
  if (sig === lastSig && h.childNodes.length) return; // nothing changed: keep inputs/focus intact
  lastSig = sig;
  const p = projects.find((x) => x.id === t.project_id);
  const badgeRow = el('div', { className: 'row' }, ...badges(t));
  if (isCloud(t)) badgeRow.append(el('span', { className: 'badge cloud', textContent: 'runs on Cursor servers (uses Pro usage)' }));
  else badgeRow.append(el('span', { className: 'badge e-local', textContent: `local: aider + ollama on this Mac${cfg ? ' (' + cfg.local_model + ')' : ''}` }));
  if (t.engine_used) badgeRow.append(el('span', { className: 'badge model', textContent: 'engine used: ' + t.engine_used }));
  if (t.allow_escalation) badgeRow.append(el('span', { className: 'badge model', textContent: 'escalation allowed' }));
  if (t.ai_review) badgeRow.append(el('span', { className: 'badge model', textContent: `AI review (${t.review_model || 'auto'})` }));
  const svcPath = t.service_id ? ((svcCache[t.project_id] || []).find((x) => x.id === t.service_id) || {}).path : null;
  const kids = [
    el('h2', { style: 'margin:0 0 4px' }, `#${t.id} ${t.title} `, el('span', { className: 'badge s-' + t.status, textContent: t.status })),
    badgeRow,
    el('div', { className: 'dim', textContent: `project: ${t.project_name || projName(t.project_id)} | service: ${t.service_name ? t.service_name + (svcPath ? ' (' + svcPath + ')' : '') : '-'} | branch: ${t.branch || '-'} | files: ${t.files.join(', ') || '-'} | check: ${t.check_cmd || (t.service_name ? 'service/' : '') + 'project default (' + (p ? p.check_cmd : '?') + ')'}${t.head_sha ? ' | head: ' + t.head_sha.slice(0, 7) : ''}` }),
    el('pre', { style: 'margin:8px 0', textContent: 'Prompt: ' + t.prompt }),
  ];
  if (t.context) kids.push(el('div', { className: 'dim', textContent: `context bundle given to the engine: ${t.context.total_chars}/${t.context.max_chars} chars (${t.context.parts.map((x) => x.name + (x.truncated ? '*' : '')).join(', ')}); file: ${t.context.file}` }));
  const rc = routingCard(t); if (rc) kids.push(rc);
  if (t.result_summary) kids.push(el('div', { className: 'card', textContent: 'Result: ' + t.result_summary }));
  if (t.supervised) kids.push(el('div', { className: 'card warnbox', textContent: 'SUPERVISED: a hands-on session (Cursor IDE / CLI) is open on this task\'s worktree. The runner is paused for it; merge and approvals are blocked. Edit as you like, then click Release: the orchestrator runs the check and commits the worktree state on the task branch (-> review).' }));
  if (t.group_id) kids.push(el('div', { className: 'dim', textContent: `Part of sequence #${t.group_id}, step ${t.step_no}${t.base_ref ? '; built on top of ' + t.base_ref : ''}. Diff tab compares against ${t.base_ref || 'the default branch'}.` }));
  if (t.status === 'awaiting_escalation') kids.push(el('div', { className: 'card warnbox', textContent: `Local attempt failed. Escalate to Cursor (model ${t.model || 'auto'})? This runs on Cursor servers and uses your Pro usage. Nothing has been sent to Cursor yet.` }));
  if (t.plan_text) {
    const pc = el('div', { className: 'card planbox' }, el('b', {}, `Cursor plan (${t.plan_state}${t.model_used ? ', model ' + t.model_used : ''})`));
    if (t.status === 'awaiting_plan') {
      planEdit[t.id] = planEdit[t.id] ?? t.plan_text;
      const ta = el('textarea', { className: 'big', style: 'min-height:240px', value: planEdit[t.id], oninput: () => { planEdit[t.id] = ta.value; } });
      pc.append(el('div', { className: 'dim', textContent: 'Read-only planning run (--mode plan). You can edit the plan; implementation (a second Cursor run, counted against the cap) starts only after you approve.' }), ta);
    } else pc.append(el('pre', { textContent: t.plan_text }));
    kids.push(pc);
  }
  if (t.review_summary) kids.push(el('div', { className: 'card advisory' }, el('pre', { textContent: t.review_summary })));
  for (const m of mp) kids.push(proposalCard(m, () => { lastSig = ''; loadMemProps().then(renderHeader); }, true));

  const pending = t.status === 'pending';
  let o = null;
  if (pending && t.routing_state !== 'routing') {
    o = ovr[t.id] || (ovr[t.id] = initOverrides(t));
    kids.push(overrideForm(t, o));
  }
  const row = el('div', { className: 'row' });
  const act = (label, cls, path, needReason, confirmMsg, bodyFn) => {
    const b = el('button', { className: cls, textContent: label });
    b.onclick = async () => {
      const body = bodyFn ? bodyFn() : {};
      if (needReason) { const r = prompt('Reason (required):'); if (!r) return; body.reason = r; }
      if (confirmMsg && !confirm(typeof confirmMsg === 'function' ? confirmMsg() : confirmMsg)) return;
      b.disabled = true;
      try { await api(`/tasks/${t.id}/${path}`, { body }); delete ovr[t.id]; delete planEdit[t.id]; } catch (e) { alert(e.message); }
      lastSig = ''; await loadList(); if (tab === 'diff') loadDiff();
    };
    row.append(b);
  };
  const base = p ? p.default_branch : 'base';
  if (pending) {
    if (t.routing_state === 'routing') kids.push(el('div', { className: 'dim', textContent: 'Approve start is available once routing finishes.' }));
    else {
      act('Approve start', 'ok', 'approve-start', false, () => (o.engine !== 'local' ? `This task runs on Cursor servers (engine ${o.engine}) and may use your Pro usage. Start it?` : null),
        () => ({ service_id: o.service_id || 'none', engine: o.engine, model: o.engine !== 'local' ? o.model : '', plan_first: o.plan_first, allow_escalation: o.allow_escalation, use_routing: !!(t.routing && t.routing.suggestion) }));
      if (t.route_requested) act('Re-route', 'sec', 'reroute', false, null, () => { delete ovr[t.id]; return {}; });
      act('Reject', 'bad', 'reject-start', true);
    }
  }
  const sup = t.supervised;
  if (t.status === 'awaiting_plan' && !sup) {
    act('Approve plan & implement', 'ok', 'approve-plan', false, 'Run the implementation with Cursor now (a second Cursor run; uses Pro usage)?', () => (planEdit[t.id] !== undefined && planEdit[t.id] !== t.plan_text ? { plan: planEdit[t.id] } : {}));
    act('Reject plan', 'bad', 'reject-plan', true);
  }
  if (t.status === 'awaiting_escalation' && !sup) {
    act('Approve escalation to Cursor', 'ok', 'approve-escalation', false, 'Run this task on Cursor servers (uses Pro usage)?');
    act('Reject escalation', 'bad', 'reject-escalation', true);
  }
  if (t.status === 'review' && !sup) {
    act(`Approve & merge into ${base}`, 'ok', 'approve-merge', false, `Merge ${t.branch} into ${base} with --no-ff in ${p ? p.path : 'the project repo'}?`);
    act('Reject', 'bad', 'reject-merge', true);
  }
  if (['running', 'checking'].includes(t.status)) act('Cancel', 'bad', 'cancel');
  if (sup) act('Release (run check + commit -> review)', 'ok', 'release', false, 'Run the check and commit the current worktree state on the task branch?');
  if (!sup && t.worktree_path && ['review', 'failed', 'awaiting_escalation', 'awaiting_plan'].includes(t.status)) {
    const openBtn = (label, mode) => {
      const b = el('button', { className: 'sec', textContent: label });
      b.onclick = async () => {
        if (!confirm(`Open this task's ${t.service_name ? 'service folder (' + t.service_name + ')' : 'worktree'} ${mode === 'ide' ? 'in the Cursor IDE' : 'in a Terminal running an interactive Cursor agent (--model auto)'}? The task becomes SUPERVISED (runner paused for it) until you click Release.`)) return;
        b.disabled = true;
        try { const r = await api(`/tasks/${t.id}/open-cursor`, { body: { mode } }); alert(r.notes.join('\n\n')); } catch (e) { alert(e.message); }
        lastSig = ''; await loadList();
      };
      row.append(b);
    };
    openBtn('Open in Cursor IDE', 'ide'); openBtn('Open Cursor CLI in Terminal', 'terminal');
  }
  kids.push(row);
  h.replaceChildren(...kids);
}

function setTab(t) {
  tab = t;
  $('#log').style.display = t === 'log' ? '' : 'none';
  $('#diff').style.display = t === 'diff' ? '' : 'none';
  $('#tab-log').className = t === 'log' ? 'on' : '';
  $('#tab-diff').className = t === 'diff' ? 'on' : '';
  if (t === 'diff') loadDiff();
}

async function loadDiff() {
  const pre = $('#diff'); if (!pre) return;
  pre.textContent = 'loading...';
  try {
    const r = await api(`/tasks/${selected}/diff`);
    pre.replaceChildren(el('div', { className: 'meta', textContent: `[${r.note || ''}]${r.truncated ? ' (truncated)' : ''}\n${r.stat || ''}` }));
    if (!r.diff) { pre.append('(no diff)'); return; }
    for (const line of r.diff.split('\n')) {
      const cls = /^(\+\+\+|---|diff |index )/.test(line) ? 'meta'
        : line.startsWith('+') ? 'add' : line.startsWith('-') ? 'del' : line.startsWith('@@') ? 'hunk' : '';
      pre.append(el('div', { className: cls, textContent: line || ' ' }));
    }
  } catch (e) { pre.textContent = 'error: ' + e.message; }
}

function startStream() {
  const log = $('#log'); const id = selected;
  if (new URLSearchParams(location.hash.slice(1)).get('nostream')) { // headless rendering: a never-ending SSE connection keeps the page 'loading'
    api(`/tasks/${id}/events`).then((rows) => rows.forEach((r) => log.append(el('div', { className: 'l-' + r.kind }, el('span', { className: 'ts', textContent: hhmmss(r.ts) + ' ' }), `[${r.kind}] ${r.message}`)))).catch(() => {});
    return;
  }
  es = new EventSource(`/api/tasks/${id}/stream`);
  es.addEventListener('log', (m) => {
    if (id !== selected) return;
    const r = JSON.parse(m.data);
    const near = log.scrollTop + log.clientHeight >= log.scrollHeight - 40;
    log.append(el('div', { className: 'l-' + r.kind },
      el('span', { className: 'ts', textContent: hhmmss(r.ts) + ' ' }), `[${r.kind}] ${r.message}`));
    if (near) log.scrollTop = log.scrollHeight;
  });
  es.addEventListener('status', () => loadList());
}

$('#create').onclick = async () => {
  $('#msg').textContent = '';
  try {
    const body = {
      project_id: $('#f-project').value, title: $('#f-title').value, prompt: $('#f-prompt').value, files: $('#f-files').value,
      check_cmd: $('#f-check').value, engine: $('#f-engine').value, model: $('#f-model').value, service_id: $('#f-service').value || 'none',
      allow_escalation: $('#f-esc').checked, ai_review: $('#f-review').checked, plan_first: $('#f-plan').checked,
    };
    if (!body.project_id) throw new Error('create or select a project first');
    const t = await api('/tasks', { body });
    ['#f-title', '#f-prompt', '#f-files', '#f-check'].forEach((s) => ($(s).value = ''));
    await loadList(); select(t.id);
  } catch (e) { $('#msg').textContent = e.message; }
};

(async () => {
  if (document.readyState !== 'complete') await new Promise((r) => window.addEventListener('load', r)); // panels.js is loaded after this file
  try { cfg = await api('/config'); $('#np-parent').value = cfg.projects_parent; $('#info').textContent = `local: ${cfg.local_model} | cursor default: ${cfg.cursor_default_model} | escalation needs approval: ${cfg.escalation_requires_approval}`; } catch { /* ignore */ }
  await loadProjects(); await loadList(); syncEngine(); loadModels();
  // deep links (also used for headless rendering): #project=<id>&task=<id>  or  #project=<id>&panel=services|context|memory|sequences|settings
  const hp = new URLSearchParams(location.hash.slice(1));
  if (hp.get('project')) { projFilter = hp.get('project'); localStorage.setItem('projFilter', projFilter); $('#proj-sel').value = projFilter; await loadList(); }
  if (hp.get('task')) select(Number(hp.get('task')));
  else if (hp.get('panel')) showProjectPanel(hp.get('panel'));
  setInterval(loadList, 3000); setInterval(loadProjects, 30000);
})();
